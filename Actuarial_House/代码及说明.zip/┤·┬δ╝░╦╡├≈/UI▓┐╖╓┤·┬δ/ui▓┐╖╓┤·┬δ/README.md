﻿# 金融服务计算项目：固定资产收益计算平台

## 本平台的生成由两个部分组成
* 打包前的前端
* 打包后的前端+后端
## 准备
### 服务器条件
* 操作系统版本： Ubuntu 16.04 64位
* CPU： 1核
* 系统内存： 2GB
* 存储空间： 20GB
### 软件准备
* node.js 版本： node-v8.9.0-linux-x64.tar     
* npm 版本：5.5.1
* python 版本：3.6.3
* mongodb 版本：mongodb-linux-x86_64-ubuntu1604-3.6.0.tgz
#### 软件安装
* nodejs (ubuntu)：
    ```
    $ cd /opt/nodejs/
    $ wget http://nodejs.org/dist/v8.9.0/node-v8.9.0-linux-x64.tar.gz
    $ tar zxvf node-v8.9.0-linux-x64.tar.gz
    $ cd node-v8.9.0-linux-x64
    $ ln -s /opt/nodejs/node-v8.9.0-linux-x64/bin/node /usr/local/bin/node 
    $ ln -s /opt/nodejs/node-v8.9.0-linux-x64/bin/npm /usr/local/bin/npm
    $ node -v
    v8.9.0
    $ npm -v
    v5.5.1
    ```
* nodejs (windows)
    * 可前往 [nodejs](https://nodejs.org/en/download/) 下载对应版本的nodejs进行安装
    * 检查系统环境变量有没有出现nodejs若无出现则自行添加
* vue-cli (开发环境）
    ```
    $ npm install --global vue-cli
    ```
* python
    * 安装过程略，建议前往 [Anacoda](https://www.anaconda.com/download/#linux) 进行安装
* mongodb
    * 安装过程略，可前往 [mongodb](https://www.mongodb.com/download-center#community) 进行下载安装
    * 由于一些故障，实际连接mongodb时，是把数据库导出成json文件并修改了一些标签来完成的
## 开发和部署
* 开发环境 vue.js
    * 过程
    ```
    # 设置一个目录，并把代码包中的 前端开发/frontend 复制到该目录下
    $ cd frontend
    $ npm install
    $ npm run dev
    # 如果需要建站更新 该命令将在 dist/ 目录下生成 static/ 和 index.html 文件 可将文件复制到后端 frontend/ 目录下
    $ npm run build
    # 由于导入element-ui插件时出现了一些问题，需要修改index.html文件：

    <!DOCTYPE html>
    <html>
        <head>
            <meta charset=utf-8>
            <title>固定资产收益计算平台（测试）</title>
            <!-- 略 -->
            <link rel="stylesheet" href="https://unpkg.com/element-ui/lib/theme-chalk/index.css">
        </head>
        <body>
            <div id=app></div>
            <script src="https://unpkg.com/element-ui/lib/index.js"></script>
            <!-- 略 -->
        </body>
    </html>

    ```
    * 你的目录结构
    ```
    Frontend/
    ├── build/  // 建站相关，内容略
    ├── config/  // 配置相关，内容略
    ├── dist/  // 建站打包生成文件目录，内容略
    ├── node_modules/  // 前端框架相关，内容略
    ├── server/  // 测试服务器部署相关，内容略
    ├── src/  // 资源目录
    │   ├── assets/  //图标目录
    │   ├── components/  //组件目录
    │   │   ├── bondTable/  
    │   │   │   ├── bondTable.vue  //债券信息组件
    │   │   │   └── Market.vue  //债券市场信息组件
    │   │   ├── dashboard/  
    │   │   │   └── dashboard.vue  // 图表分析页面组件你
    │   │   ├── filter/  //曲线信息过滤组件
    │   │   │   └── filter.vue
    │   │   ├── header/  //曲线头部组件目录
    │   │   │   └── header.vue
    │   │   ├── info/ 
    │   │   │   └── about.vue  //项目相关信息组件
    │   │   ├── myline/  //曲线图像组件目录
    │   │   │   ├── convexity_ytm.vue //凸性 vs 收益率曲线
    │   │   │   ├── duration_ytm.vue //修正久期vs收益率曲线
    │   │   │   └── line.vue // 价格vs收益率曲线
    │   │   ├── tools/  //工具箱组件目录
    │   │   │   └── calculate.vue // 债券计算器组件
    │   │   ├── 404.vue  //非法访问页面
    │   │   ├── home.vue  //主页
    │   ├── styles  //页面风格相关，内容略
    │   ├── App.vue //第一组件
    │   └── main.js  //组件组成脚本
    ├── static/  //静态资源文件
    │   ├── bond/  //债券信息
    │   │   ├── bondData.json  //债券信息
    │   │   ├── bondLabel.json  //债券标签信息
    │   │   ├── marketLabel.json  //市场标签信息
    │   │   └── publication.json  //发行方类别信息
    │   ├── css/  //css文件，内容略
    │   ├── data/ //曲线数据文件
    │   │   ├── convexity_ytm.json  //凸性和到期收益率曲线数据文件
    │   │   ├── duration_ytm  //修正久期和到期收益率曲线数据文件
    │   │   └── price_ytm.json  //价格和到期收益率曲线数据文件
    │   ├── fonts/  //字体文件，内容略
    │   ├── img/  //图像文件，内容略
    │   ├── js/  //js脚本文件，内容略
    │   └── data.json  //其它数据
    ├── // 略去一些配置文件
    ├── package.json //所使用的框架目录
    └── index.html //测试主页

    ```
* 前后端分离
    * 参考django官方文档的 [quick start](https://docs.djangoproject.com/en/2.0/intro/tutorial01/)
    * 参考博文[前后端分离](https://zhuanlan.zhihu.com/p/25080236)
    * 过程
    ```
    # 确保您的python3已经安装成功后，安装 django 后端
    pip install django
    # 为了使前端可以访问后端接口
    pip install django-cors-headers
    # 访问你要进入的目录，并建立项目
    $ django-admin startproject bond
    $ cd bond
    $ python manage.py startapp backend
    $ mkdir frontend
    
    # 用代码包中的 前后端分离/frontend/* 复制到 frontend/* 下
    # 用代码包中的 前后端分离/bondv2/bondv2/urls.py 覆盖 bond/bond/urls.py 
    # 用代码包中的 前后端分离/bondv2/backend/ 覆盖 bond/backend/
    
    # 修改 前后端分离/bond/bond/settings.py，添加前端目录
    
    TEMPLATES = [
        {
            'BACKEND': 'django.template.backends.django.DjangoTemplates',
            'DIRS': ['frontend'],  # 修改
            'APP_DIRS': True,
            'OPTIONS': {
                'context_processors': [
                    'django.template.context_processors.debug',
                    'django.template.context_processors.request',
                    'django.contrib.auth.context_processors.auth',
                    'django.contrib.messages.context_processors.messages',
                ],
            },
        },
    ]
    # 关闭调试
    DEBUG = False
    # 修改端口
    ALLOWED_HOSTS = ['120.79.57.120']

    # 修改 bond/bond/settings.py, 添加前端静态文件目录

    STATICFILES_DIRS = [
        os.path.join(BASE_DIR, "frontend/dist/static"),
    ]
    # 修改 bond/bond/settings.py, 添加跨域访问方法
    MIDDLEWARE = [
        'django.middleware.security.SecurityMiddleware',
        'django.contrib.sessions.middleware.SessionMiddleware',
        'corsheaders.middleware.CorsMiddleware',  # 添加
        'django.middleware.common.CommonMiddleware',
        'django.middleware.csrf.CsrfViewMiddleware',
        'django.contrib.auth.middleware.AuthenticationMiddleware',
        'django.contrib.messages.middleware.MessageMiddleware',
        'django.middleware.clickjacking.XFrameOptionsMiddleware',
    ]
    CORS_ORIGIN_ALLOW_ALL = True

    # 发布网站
    $ python manage.py runserver 0.0.0.0:8083

    ```
    * 你的目录结构
    ```
    bond  //文件目录
    ├── backend/
    │   ├── bond_model/  //计算模型
    │   │   ├── data/  //模型所需数据，部分信息略
    │   │   │   ├── company-A+.xlsx  // 公司A+债券相关信息
    │   │   │   └── country.xlsx  //国债相关信息
    │   │   ├── Analysis.py  //分析和计算
    │   │   ├── getxlxs.py  //爬取债券信息
    │   │   ├── IRmodel.py  //利率模型
    │   │   ├── test0.py  //生成利率等曲线
    │   │   ├── Readme
    │   │   └── __init__.py
    │   ├── migrations/
    │   │   └── __init__.py
    │   ├── __init__.py
    │   ├── admin.py
    │   ├── app.py
    │   ├── models.py
    │   ├── search.py  //设计api计算接口具体形式 
    │   ├── tests.py
    │   ├── urls.py  //设置api接口
    │   └── views.py
    ├── frontend/  //打包生成的前端
    │   ├── static/  //静态数据文件目录
    │   │   ├── bond/  //债券信息
    │   │   │   ├── bondData.json  //债券信息
    │   │   │   ├── bondLabel.json  //债券标签信息
    │   │   │   ├── marketLabel.json  //市场标签信息
    │   │   │   └── publication.json  //发行方类别信息
    │   │   ├── css/  //css文件，内容略
    │   │   ├── data/  //曲线数据文件
    │   │   │   ├── convexity_ytm.json  //凸性和到期收益率曲线数据文件
    │   │   │   ├── duration_ytm  //修正久期和到期收益率曲线数据文件
    │   │   │   └── price_ytm.json  //价格和到期收益率曲线数据文件
    │   │   ├── fonts/  //字体文件，内容略
    │   │   ├── img/  //图像文件，内容略
    │   │   ├── js/  //js脚本文件，内容略
    │   │   └── data.json  //其它数据
    │   └── index.html  //主页
    ├── manage.py  //运行文件
    └── bond/  
        ├── __init__.py
        ├── settings.py  // 系统设置
        ├── urls.py
        └── wsgi.py

    ``` 