# -*- coding: utf-8 -*-

import numpy
import requests
import xlrd
from scipy.interpolate import CubicSpline
def cal_intrRate(period, type='country'):
	list = ['country', 'company-AAA', 'company-AAA-', 'company-AA+', 'company-AA', 'company-AA-', 'company-A+',
			'company-A', 'company-A-',
			'company-BBB+', 'company-BBB', 'company-BB', 'company-B', 'company-CCC', 'company-CC']
	index = 0
	for i in range(len(list)):
		if list[i]==type:
			index = i
			break
	# print(list[index])
	workbook = xlrd.open_workbook('/root/bond/bondv2/backend/bond_model/data/'+list[index]+'.xlsx')
	sheet1 = workbook.sheet_by_index(0)
	year =  sheet1.col_values(1)
	percent = sheet1.col_values(2)
	x = []
	y = []
	index = 0
	for i in year:
		if index:
			#print(i)
			x.append(i)
		index += 1
	index = 0
	for i in percent:
		if index:
			#print(i)
			y.append(float(i)/100)
		index += 1
	
#x = [0,0.08,0.17,0.25,0.5,0.75,1,3,5,7,10,15,20,30,40,50]
#y = [0.024408,0.039821,0.040265,0.039582,0.039454,0.038186,0.037979,0.037951,0.038133,0.03915,0.038731,0.041708,0.042096,0.04362,0.04402,0.044124]
	cs = CubicSpline(x, y)

	return cs(period)
