import requests
import xlrd
import sys

def select_url(argv):
	if argv == 'country':
		url = "http://yield.chinabond.com.cn/cbweb-mn/yc/downBzqxDetail?ycDefIds=2c9081e50a2f9606010a3068cae70001&&zblx=txy&&workTime=&&dxbj=&&qxlx=&&yqqxN=&&yqqxK=&&wrjxCBFlag=0&&locale=zh_CN"
	elif argv == 'company-AAA':
		url = "http://yield.chinabond.com.cn/cbweb-mn/yc/downBzqxDetail?ycDefIds=2c9081e50a2f9606010a309f4af50111&&zblx=txy&&workTime=&&dxbj=0&&qxlx=0,&&yqqxN=N&&yqqxK=K&&wrjxCBFlag=0&&locale=zh_CN"
	elif argv == 'company-AAA-':
		url = "http://yield.chinabond.com.cn/cbweb-mn/yc/downBzqxDetail?ycDefIds=8a8b2ca045e879bf014607ebef677f8e&&zblx=txy&&workTime=&&dxbj=0&&qxlx=0,&&yqqxN=N&&yqqxK=K&&wrjxCBFlag=0&&locale=zh_CN"
	elif argv == 'company-AA+':
		url = "http://yield.chinabond.com.cn/cbweb-mn/yc/downBzqxDetail?ycDefIds=2c908188138b62cd01139a2ee6b51e25&&zblx=txy&&workTime=&&dxbj=0&&qxlx=0,&&yqqxN=N&&yqqxK=K&&wrjxCBFlag=0&&locale=zh_CN"
	elif argv == 'company-AA':
		url = "http://yield.chinabond.com.cn/cbweb-mn/yc/downBzqxDetail?ycDefIds=2c90818812b319130112c279222836c3&&zblx=txy&&workTime=&&dxbj=0&&qxlx=0,&&yqqxN=N&&yqqxK=K&&wrjxCBFlag=0&&locale=zh_CN"
	elif argv == 'company-AA-':
		url = "http://yield.chinabond.com.cn/cbweb-mn/yc/downBzqxDetail?ycDefIds=8a8b2ca045e879bf014607f9982c7fc0&&zblx=txy&&workTime=&&dxbj=0&&qxlx=0,&&yqqxN=N&&yqqxK=K&&wrjxCBFlag=0&&locale=zh_CN"
	elif argv == 'company-A+':
		url = "http://yield.chinabond.com.cn/cbweb-mn/yc/downBzqxDetail?ycDefIds=2c9081e91b55cc84011be40946ca0925&&zblx=txy&&workTime=&&dxbj=0&&qxlx=0,&&yqqxN=N&&yqqxK=K&&wrjxCBFlag=0&&locale=zh_CN"
	elif argv == 'company-A':
		url = "http://yield.chinabond.com.cn/cbweb-mn/yc/downBzqxDetail?ycDefIds=2c9081e91e6a3313011e6d438a58000d&&zblx=txy&&workTime=&&dxbj=0&&qxlx=0,&&yqqxN=N&&yqqxK=K&&wrjxCBFlag=0&&locale=zh_CN"
	elif argv == 'company-A-':
		url = "http://yield.chinabond.com.cn/cbweb-mn/yc/downBzqxDetail?ycDefIds=8a8b2ca04142df6a014148ca880f3046&&zblx=txy&&workTime=&&dxbj=0&&qxlx=0,&&yqqxN=N&&yqqxK=K&&wrjxCBFlag=0&&locale=zh_CN"
	elif argv == 'company-BBB+':
		url = "http://yield.chinabond.com.cn/cbweb-mn/yc/downBzqxDetail?ycDefIds=2c9081e91ea160e5011eab1f116c1a59&&zblx=txy&&workTime=&&dxbj=0&&qxlx=0,&&yqqxN=N&&yqqxK=K&&wrjxCBFlag=0&&locale=zh_CN"
	elif argv == 'company-BBB':
		url = "http://yield.chinabond.com.cn/cbweb-mn/yc/downBzqxDetail?ycDefIds=8a8b2ca0455847ac0145650780ad68fb&&zblx=txy&&workTime=&&dxbj=0&&qxlx=0,&&yqqxN=N&&yqqxK=K&&wrjxCBFlag=0&&locale=zh_CN"
	elif argv == 'company-BB':
		url = "http://yield.chinabond.com.cn/cbweb-mn/yc/downBzqxDetail?ycDefIds=8a8b2ca0455847ac0145650ba23b68ff&&zblx=txy&&workTime=&&dxbj=0&&qxlx=0,&&yqqxN=N&&yqqxK=K&&wrjxCBFlag=0&&locale=zh_CN"
	elif argv == 'company-B':
		url = "http://yield.chinabond.com.cn/cbweb-mn/yc/downBzqxDetail?ycDefIds=8a8b2ca0455847ac0145650c3d726901&&zblx=txy&&workTime=&&dxbj=0&&qxlx=0,&&yqqxN=N&&yqqxK=K&&wrjxCBFlag=0&&locale=zh_CN"
	elif argv == 'company-CCC':
		url = "http://yield.chinabond.com.cn/cbweb-mn/yc/downBzqxDetail?ycDefIds=8a8b2ca0455847ac0145650d03d26903&&zblx=txy&&workTime=&&dxbj=0&&qxlx=0,&&yqqxN=N&&yqqxK=K&&wrjxCBFlag=0&&locale=zh_CN"
	elif argv == 'company-CC':
		url = "http://yield.chinabond.com.cn/cbweb-mn/yc/downBzqxDetail?ycDefIds=8a8b2ca0447ffc96014491641747535e&&zblx=txy&&workTime=&&dxbj=0&&qxlx=0,&&yqqxN=N&&yqqxK=K&&wrjxCBFlag=0&&locale=zh_CN"
	return url

def main():
	list = ['country', 'company-AAA', 'company-AAA-', 'company-AA+', 'company-AA', 'company-AA-', 'company-A+', 'company-A', 'company-A-',
			'company-BBB+', 'company-BBB', 'company-BB', 'company-B', 'company-CCC', 'company-CC']
	a = requests.session()
	for i in range(len(list)):
		#hea = {'User-Agent':'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2272.118 Safari/537.36'}
		#cook = {'JSESSIONID':'0000Ag8lVzHTuJpdgXS3snp0cNO:-1'}
		#requests.utils.add_dict_to_cookiejar(a.cookies, cook)
		#host = "yield.chinabond.com.cn"
		f = open('./data/'+list[i]+'.xlsx', 'wb')
		url = select_url(list[i])
		data = a.get(url=url).content
		f.write(data)
		f.close()
if __name__=='__main__':
	main()