#!/usr/bin/env python
# -*- coding: utf-8 -*-

from Analysis import *
import json
settle = '2017-12-26'
mature = '2029-04-17'
value = 100
freq = 2
coupon = 0.034
type1 = 'country'
# type1 = 'company-BBB'
def calculate(settle, mature, value, freq, coupon, type):
    res1 = analysis_using_IRmodel(settle,value, mature,coupon,freq,type)
    result = {"result":[
        {"pv":res1['pv'], "clean_price":res1['clean_price'], "ytm": res1['ytm'], "duration":res1['duration']
         , "convexity":res1['convexity']}
    ]}
    return result
res1 = calculate(settle, mature, value, freq, coupon, type1)
print(res1)
#ytm = 0.0395
#res2 = analysis_using_ytm(settle,mature,coupon,freq,ytm)
#print(res2)
#pv = 1.0091
#res3 = analysis_using_pv(settle,mature,coupon,freq,pv)
#:print(res3)
