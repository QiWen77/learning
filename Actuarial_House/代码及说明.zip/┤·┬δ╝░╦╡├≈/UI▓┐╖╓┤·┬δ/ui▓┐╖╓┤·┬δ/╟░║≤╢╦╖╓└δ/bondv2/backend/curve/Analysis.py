#!/usr/bin/env python
# -*- coding: utf-8 -*-
from datetime import datetime
import time
import dateutil.relativedelta
from scipy.optimize import fsolve
import math

#导入利率模型
from .IRmodel import cal_intrRate

def str2date(string):
    return datetime.strptime(string, '%Y-%m-%d')
def date_change(start, delta):
    return start+dateutil.relativedelta.relativedelta(months=delta)
def coupon_n(settle, mature, freq):
    n=int(freq*(mature-settle).days/365.25)
    m=-int(12/freq)
    while (date_change(mature,n*m)<=settle):
        n=n-1
    while (date_change(mature,(n+1)*m)>settle):
        n=n+1
    n=n+1
    return n
def coupon_prev_next(settle,mature,freq):
    m=-int(12/freq)
    n=coupon_n(settle,mature,freq)
    return date_change(mature,n*m),date_change(mature,(n-1)*m)

def cal_cashflow(settle,mature,coupon,freq):
    n=coupon_n(settle,mature,freq)
    m=-int(12/float(freq))
    cash,cashflow=[],{}
    for i in range(n-1):
        cash.append(coupon/freq)
    cash.append(coupon/freq+1)
    dates=[date_change(mature,m*j) for j in range(n-1,-1,-1)]
    time_series=[-m*i/float(12) for i in range(1,n+1)]
    cashflow['cash'],cashflow['date'],cashflow['T_in_year']=cash,dates,time_series
    return cashflow

def cal_pv_using_interest_model(settle,mature,coupon,freq,type):
    #settle, mature = str2date(settle), str2date(mature)
    c_prev,c_next = coupon_prev_next(settle,mature,freq)
    x = (settle - c_prev).days / float((c_next - c_prev).days)
    cashflow = cal_cashflow(settle,mature,coupon,freq)
    rates = [cal_intrRate(t-1 / float(freq) * x, type) for t in cashflow['T_in_year']] #使用利率模型
    discounts = [math.pow((1 + r/freq),(-j-1+x)) for j,r in enumerate(rates)]  
    return sum([cashflow['cash'][i] * discounts[i] for i in range(len(cashflow['cash']))])

def bondanalysis_using_pv(settle,mature,coupon,freq,pv,value):
    def cal_ytm_using_pv(n,cashflow,x,freq,pv):
        def func(r):
            return cal_pv_using_ytm(n,cashflow,x,freq,r) - pv
        ytm_ = fsolve(func,0)
        return ytm_[0]
    def cal_pv_using_ytm(n,cashflow,x,freq,ytm):
        disc_ytm=[math.pow((1 + ytm/freq),(-j-1)) for j in range(n)]
        return sum([cashflow['cash'][i] * disc_ytm[i] for i in range(n)]) * math.pow(1 + ytm/freq,x)
    
    n = coupon_n(settle,mature,freq)
    c_prev,c_next = coupon_prev_next(settle,mature,freq)
    x = (settle-c_prev).days / float((c_next-c_prev).days)
    cashflow = cal_cashflow(settle,mature,coupon,freq)
    ytm = cal_ytm_using_pv(n,cashflow,x,freq,pv)
    
    disc_ytm=[math.pow((1 + ytm/freq),(-j-1+x)) for j in range(n)]
    modified_duration = sum([(float(i+1-x)/freq)*cashflow['cash'][i]*disc_ytm[i] for i in range(n)])/(pv*(1+ytm/freq))
    disc_ytm_convexity = [math.pow((1+ytm/freq),(-j-3+x)) for j in range(n)]
    convexity = sum([(float(i+1-x)*(i+2-x)/math.pow(freq,2))*cashflow['cash'][i]*disc_ytm_convexity[i] for i in range(n)])/pv
    clean_price = pv - x * coupon / freq
    return {"pv":pv*value,"ytm":ytm,"duration":modified_duration,"convexity":convexity,"clean_price":clean_price*value}

def bondanalysis_using_ytm(settle,mature,coupon,freq,ytm):
    def cal_pv_using_ytm(n,cashflow,x,freq,ytm):
        disc_ytm=[math.pow((1 + ytm/freq),(-j-1)) for j in range(n)]
        return sum([cashflow['cash'][i] * disc_ytm[i] for i in range(n)]) * math.pow(1 + ytm/freq,x)
    
    n = coupon_n(settle,mature,freq)
    c_prev,c_next = coupon_prev_next(settle,mature,freq)
    x = (settle-c_prev).days / float((c_next-c_prev).days)
    cashflow = cal_cashflow(settle,mature,coupon,freq)
    pv =cal_pv_using_ytm(n,cashflow,x,freq,ytm)
    
    disc_ytm=[math.pow((1 + ytm/freq),(-j-1+x)) for j in range(n)]
    modified_duration = sum([(float(i+1-x)/freq)*cashflow['cash'][i]*disc_ytm[i] for i in range(n)])/(pv*(1+ytm/freq))
    disc_ytm_convexity = [math.pow((1+ytm/freq),(-j-3+x)) for j in range(n)]
    convexity = sum([(float(i+1-x)*(i+2-x)/math.pow(freq,2))*cashflow['cash'][i]*disc_ytm_convexity[i] for i in range(n)])/pv
    clean_price = pv - x * coupon / freq
    return {'pv':pv,'ytm':ytm,'duration':modified_duration,'convexity':convexity,'clean_price':clean_price}

#输入 
#settle交易日,mature到期日：形如'2017-11-18'的字符串；
#coupon票面利率：小数 例如4.2%，则其值为0.042
#freq付息次数：1 or 2
#输出：{'全价':pv,'到期收益率':ytm,'修正久期':modified_duration,'凸性':convexity,'净价':clean_price}

#该函数是没有给定到期收益率和现值时，通过利率模型进行计算得出相应结果
def analysis_using_IRmodel(settle,value,mature,coupon,freq,type):
    settle = str2date(settle)
    mature = str2date(mature)
    pv = cal_pv_using_interest_model(settle,mature,coupon,freq,type)
    return bondanalysis_using_pv(settle,mature,coupon,freq,pv,value)

#如果给定了到期收益率
def analysis_using_ytm(settle,mature,coupon,freq,ytm):
    settle = str2date(settle)
    mature = str2date(mature)
    return bondanalysis_using_ytm(settle,mature,coupon,freq,ytm)

#如果给定了现值（全价）	
def analysis_using_pv(settle,mature,coupon,freq,pv):
    settle = str2date(settle)
    mature = str2date(mature)
    return bondanalysis_using_pv(settle,mature,coupon,freq,pv)

#零息债券 返回值：价格,收益率
def analysis_zero_coupon(settle,mature,freq,facevalue):
    settle = str2date(settle)
    mature = str2date(mature)
    years = (mature-settle).days / 365.0
    return facevalue/math.pow(1+cal_intrRate(years)/freq,years*freq),cal_intrRate(years)
