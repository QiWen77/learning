import random
import unittest
from Analysis import *
import Analysis
from datetime import datetime
import dateutil.relativedelta


class TestAnalysisFunction(unittest.TestCase):

	def setUp(self):
		self.settle = str2date('2015-11-11')
		self.mature = str2date('2017-11-11')

	def tearDown(self):
		pass

	def teststr2date(self):
		self.assertEqual(Analysis.str2date('2017-01-01'), datetime.strptime('2017-01-01', '%Y-%m-%d'))
		self.assertEqual(Analysis.str2date('2017-01-02'), datetime.strptime('2017-01-02', '%Y-%m-%d'))
		self.assertEqual(Analysis.str2date('2017-01-03'), datetime.strptime('2017-01-03', '%Y-%m-%d'))

	def testcoupon_n(self):
		result = coupon_n(self.settle, self.mature,3)
		self.assertEqual(result, 6)
		result = coupon_n(self.settle, self.mature,2)
		self.assertEqual(result, 4)
		result = coupon_n(self.settle, self.mature,1)
		self.assertEqual(result, 2)

	def testcoupon_prev_next(self):
		r = coupon_prev_next(self.settle, self.mature, 1)
		self.assertEqual(r, (datetime(2015, 11, 11, 0, 0), datetime(2016, 11, 11, 0, 0)))
		r = coupon_prev_next(self.settle, self.mature, 2)
		self.assertEqual(r, (datetime(2015, 11, 11, 0, 0), datetime(2016, 5, 11, 0, 0)))

	def testcal_cashflow(self):
		r = cal_cashflow(self.settle, self.mature, 0.1, 2)
		true_r = {'cash': [0.05, 0.05, 0.05, 1.05], 'date': [datetime(2016, 5, 11, 0, 0), datetime(2016, 11, 11, 0, 0), datetime(2017, 5, 11, 0, 0), datetime(2017, 11, 11, 0, 0)], 'T_in_year': [0.5, 1.0, 1.5, 2.0]}
		self.assertEqual(r, true_r)

	def testcal_pv_using_interest_model(self):
		r = cal_pv_using_interest_model(self.settle, self.mature, 0.1, 2, 'country')
		true_r = 1.1179512642857112
		self.assertEqual(r, true_r)

	def testbondanalysis_using_pv(self):
		r = bondanalysis_using_pv(self.settle, self.mature, 0.1, 2, 100, 100)
		true_r = {'pv': 10000, 'ytm': -2.6383047199086205, 'duration': -6.2826780807673321, 'convexity': 49.29037759843213, 'clean_price': 10000.0}
		self.assertEqual(r, true_r)

	def testbondanalysis_using_ytm(self):
		r = bondanalysis_using_ytm(self.settle, self.mature, 0.1, 2, 0.2)
		true_r = {'pv': 0.8415067276825352, 'ytm': 0.2, 'duration': 1.6795916635614698, 'convexity': 3.715520158735641, 'clean_price': 0.8415067276825352}
		self.assertEqual(r, true_r)

	def testanalysis_using_IRmodel(self):
		pass

	def testanalysis_using_ytm(self):
		r = analysis_using_ytm('2015-01-01', '2017-01-01', 0.1, 2, 0.1)
		ture_r = {'pv': 1.0, 'ytm': 0.1, 'duration': 1.77297525208118, 'convexity': 4.118458382885241, 'clean_price': 1.0}
		self.assertEqual(r, ture_r)

	def testanalysis_using_pv(self):
		pass

	def testanalysis_zero_coupon(self):
		pass

if __name__ == '__main__':
	unittest.main()