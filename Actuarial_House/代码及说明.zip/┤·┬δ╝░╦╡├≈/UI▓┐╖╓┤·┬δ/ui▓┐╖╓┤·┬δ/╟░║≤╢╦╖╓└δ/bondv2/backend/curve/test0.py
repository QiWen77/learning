#!/usr/bin/env python
# -*- coding: utf-8 -*-

from .Analysis import *
import json
settle = '2017-12-26'
mature = '2023-04-17'
value = 100
freq = 2
coupon = 0.034
type1 = 'country'
# type1 = 'company-BBB'
def calculate(settle, mature, value, freq, coupon, type):
    res1 = analysis_using_IRmodel(settle,value, mature,coupon,freq,type)
    result = {"result":[
        {"pv":res1['pv'], "clean_price":res1['clean_price'], "ytm": res1['ytm'], "duration":res1['duration']
         , "convexity":res1['convexity']}
    ]}
    return result
res1 = calculate(settle, mature, value, freq, coupon, type1)
print(res1)
#ytm = 0.0395
#res2 = analysis_using_ytm(settle,mature,coupon,freq,ytm)
#print(res2)
#pv = 1.0091
#res3 = analysis_using_pv(settle,mature,coupon,freq,pv)
#:print(res3)
def get_array(settle, mature, value, freq, coupon, type,  sel='duration'):
    # def analysis_using_ytm(settle, mature, coupon, freq, ytm):
    #     settle = str2date(settle)
    #     mature = str2date(mature)
    #     return bondanalysis_using_ytm(settle, mature, coupon, freq, ytm)
    res1 = analysis_using_IRmodel(settle,value, mature,coupon,freq,type)
    rate = res1['ytm']
    x = []
    y = []
    z = []
    for i in range(-100,100):
        tmprate = rate-0.005+i*0.001
        x.append(tmprate)
        tmpres = analysis_using_ytm(settle, mature, coupon, freq, tmprate)
        y.append([tmprate, tmpres['duration']])
        z.append([tmprate, tmpres['convexity']])
    result_duration = {"data": y}
    json.dump(result_duration, open('/root/bond/bondv2/frontend/static/data/duration_ytm.json', 'w'))
    result_convexity = {"data": z}
    json.dump(result_convexity, open('/root/bond/bondv2/frontend/static/data/convexity_ytm.json', 'w'))
    if sel == 'duration':
        return result_duration
    else:
        return result_convexity