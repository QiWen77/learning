# -*- coding: utf-8 -*-
 
from django.http import HttpResponse
from django.shortcuts import render_to_response
from .bond_model import Analysis, IRmodel
from .curve import test0
import json

# 表单
def search_form(request):
    return render_to_response('./test/s.html')
 
# get_array(settle, mature, value, freq, coupon, type,  sel='duration')
# 接收请求数据
def search(request):  
    request.encoding = 'utf-8'
    # settle = '2017-1-1'
    # mature = '2017-1-1'
    # coupon = 0.05
    # freq = 1
    # method = 1
    type = "country"
    value = 100
    if 's' and 'm' and 'c' and 'f' and 'me' in request.GET:
        settle = request.GET['s']
        mature = request.GET['m']
        coupon = float(request.GET['c'])
        freq = int(request.GET['f'])
        method = int(request.GET['me'])
        if method not in [1, 2, 3, 4]:
            return HttpResponse('')
    else:
        return HttpResponse('')

    if method == 2:
        if 'ytm' in request.GET:
            ytm = float(request.GET['ytm'])
        else:
            return HttpResponse('')
        msg = Analysis.analysis_using_ytm(settle, mature, coupon, freq, ytm)
    elif method == 3:
        if 'pv' in request.GET:
            pv = float(request.GET['pv'])
        else:
            return HttpResponse('')
        msg = Analysis.analysis_using_pv(settle, mature, coupon, freq, pv)
    else:
        msg = Analysis.analysis_using_IRmodel(settle, 100, mature, coupon, freq, 'country')
    test0.get_array(settle, mature, value, freq, coupon, type,  sel='duration')
    for keyw in msg:
        msg[keyw] = str(msg[keyw])
    msg = json.dumps(msg)
    return HttpResponse(msg)

# analysis_using_IRmodel(settle, mature, coupon, freq)
# 输入
# settle交易日,mature到期日：形如'2017-11-18'的字符串；
# coupon票面利率：小数 例如4.2%，则其值为0.042
# freq付息次数：1 or 2
# 输出：{'全价':pv,'到期收益率':ytm,'修正久期':modified_duration,'凸性':convexity,'净价':clean_price}

# 该函数是没有给定到期收益率和现值时，通过利率模型进行计算得出相应结果
