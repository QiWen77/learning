export default function getUrl(str) {
　　let url = 'http://localhost:8081/' + str;
　　return url;
}