<template>
  <div id="app" style="width:1650px">
    <el-row>
      <el-col :span="24">
        <el-form :inline="true" ref="form" class="demo-form-inline" style="margin-top:20px">
          <el-form-item label="债券代码">
            <el-input v-model.number="form.bondCode" placeholder="sh010107"></el-input>
          </el-form-item>
          <!-- <el-button type="primary" @click.native.prevent="trydjango()">python</el-button> -->
          <el-button type="primary" @click.native.prevent="search()">查询</el-button>
          <el-button type="primary" @click.native.prevent="reset()">重置</el-button>
        </el-form>
      </el-col>
    </el-row>
    <div style="margin-bottom:10px">
      <el-pagination
        layout="total, sizes, prev, pager, next, jumper"
        @size-change="handleSizeChange"
        @current-change="handleCurrentChange"
        :page-sizes="[10, 20, 30, 40]"
        :page-size="pageSize"
        :total="pagenum">
      </el-pagination>
    </div>
    <!-- <div>{{ notice }}</div> -->
    <el-table
      ref="multipleTable"
      :data="tableData" 
      border
      height="700"
      tooltip-effect="dark"
      style="margin-top: 20px, font-size: 12px"
      @selection-change="handleSelectionChange">
      <el-table-column type="selection" width="30" align="center"></el-table-column>
      <el-table-column type="index" label="序号" width="30" align="center"></el-table-column>
      <template v-for="item in tableLabel">
        <el-table-column :prop="item.prop" :label="item.name" align="center"></el-table-column>
      </template>
<!--       <el-table-column prop="symbol" label="债券代码" width="80" align="center"></el-table-column>
      <el-table-column prop="name" label="债券简称" width="100" align="center"></el-table-column> -->
    </el-table>
    
  </div>
</template>

<script>
  // import py from './py_test.py'
  import axios from 'axios'
  export default {
    data() {
      return {
        form: {
          bondCode: "sh010107"
        },
        pagenum: 1,
        pageSize: 20,
        tableLabel: [],
        tableData: [],
        notice: 'notice'
      }
    },
    created: function() {
      this._getLabels()
      this.reset()
    },
    methods: {
      // 读取市场信息表的表格标签
      _getLabels() {
        axios.get('static/bond/bondLabel.json').then((res) => {
          // this.notice = res.data.marketLabel.slice(0, 3)
          this.tableLabel = res.data.marketLabel
        })
      },
      handleSizeChange(val) {
        this.pageSize = val
        this.reset()
        console.log(`每页 ${val} 条`);
      },
      // 显示当前页码的内容
      handleCurrentChange(val) {
        axios.get('static/bond/bondData.json').then((res) => {
          var start = (val - 1) * this.pageSize
          var tmp = res.data.bondInfo.slice(start, start + this.pageSize)
          var i = 0
          this.tableData = []
          while (i < this.pageSize) {
            this.tableData[i] = tmp[i].info
            // this.notice = tmp[i].info
            i++
          }
          i = 0
          while (res.data.bondInfo[i]) {
            i++
          }
          this.pagenum = i
          console.log(`当前页: ${val}`);
        })
      },
      // 搜索某一条数据
      search() {
        axios.get('static/bond/bondData.json').then((res) => {
          var i = 0
          while (res.data.bondInfo[i]) {
            if (res.data.bondInfo[i].symbol === this.form.bondCode) {
              this.tableData = [res.data.bondInfo[i].info]
              break
            }
            i++
          }
        })
        console.log(`债券代码: ${this.form.bondCode}`)
      },
      // 重置为初始状态
      reset() {
        this.handleCurrentChange(1)
      },
      // 处理表格中的选择
      handleSelectionChange (val) {
        this.multipleSelection = val
        this.counter = val.length
      }
    }
  }
</script>