<template>
  <div id="app">
    <el-form :inline="true" ref="formFind" class="demo-form-inline">
      <el-form-item 
        :rules="{required: true, message: '请输入债券代码', trigger: 'blur'}"
        prop="BOND_CODE" label="债券代码">
        <el-input v-model="formFind.BOND_CODE" placeholder="债券代码"></el-input>
      </el-form-item>
      <el-form-item>
        <el-button type="primary" icon="el-icon-search" @click="findBond()">查询</el-button>
        <el-button type="primary" @click.native.prevent="toggleSelection()">取消选择</el-button>
        <el-button type="primary" @click.native.prevent="invertSelection()">反选</el-button>
        <el-button type="primary" @click.native.prevent="refresh()">载入数据</el-button>
        <el-button disabled type="primary" @click.native.prevent="addBond()">加入对比</el-button>
      </el-form-item>
    </el-form>
    <!--el-pagination layout="prev, pager, next" @current-change="handleCurrentChange" :page-size="20" :total="total" style="float:right;">
    </el-pagination-->
    <el-table
      ref="multipleTable"
      :data="tableData" 
      border
      height=800
      tooltip-effect="dark"
      style="margin-top: 10px, font-size: 12px"
      @selection-change="handleSelectionChange">
      <el-table-column type="selection" width="50" align="center"></el-table-column>
      <el-table-column type="index" label="序号" width="50" align="center"></el-table-column>
      <el-table-column prop="BOND_CODE" label="债券代码" width="80" align="center"></el-table-column>
      <el-table-column prop="BOND_ABBR" label="债券简称" width="100" align="center"></el-table-column>
      <el-table-column prop="BOND_FULL" label="债券全称" width="250" align="center"></el-table-column>
      <el-table-column prop="TERM_YEAR" label="期限(年)" width="80" align="center"></el-table-column>
      <el-table-column prop="INTEREST_TYPE" label="计息方式" width="80" align="center"></el-table-column>
      <el-table-column prop="PAY_TYPE" label="付息方式" width="80" align="center"></el-table-column>
      <el-table-column prop="ISSUE_VALUE" label="发行量(亿元)" width="110" align="center"></el-table-column>
      <el-table-column prop="LISTING_DATE" label="上市日期" width="100" align="center"></el-table-column>
      <el-table-column prop="END_DATE" label="到期日" width="100" align="center"></el-table-column>
    </el-table>
  </div>
</template>
<script>
import axios from 'axios'
export default {
  data () {
    return {
      formFind: {
        BOND_CODE: '',
        BOND_ABBR: '',
        BOND_FULL: '',
        TERM_YEAR: ''
      },
      counter: 0,
      tableData: [],
      multipleSelection: []
    }
  },
  created: function() {
    this.refresh()
  },
  methods: {
    toggleSelection (rows) {
      if (rows) {
        rows.forEach(row => {
          this.$refs.multipleTable.toggleRowSelection(row)
        })
      } else {
        this.$refs.multipleTable.clearSelection()
      }
    },
    handleSelectionChange (val) {
      this.multipleSelection = val
      this.counter = val.length
    },
    invertSelection (rows) {
      for (var i = 0; i < this.tableData.length; i++) {
        this.$refs.multipleTable.toggleRowSelection(this.tableData[i])
      }
    },
    refresh () {
      axios.get('static/data.json').then((res) => {
        this.tableData = res.data.tableData
      })
      console.log("载入数据")
    },
    findBond () {
      var newTableData = []
      var j = 0
      console.log(this.formFind.BOND_CODE)
      // if (this.formFind.BOND_CODE != '' && this.formFind.BOND_CODE !="债券代码" )
      // {
      for (var i = 0; i < this.tableData.length; i++) {
        if (this.formFind.BOND_CODE === this.tableData[i].BOND_CODE) {
          newTableData[j] = this.tableData[i]
          j++
        }
      }
      // }
      this.tableData = newTableData
    }
  }
}
</script>