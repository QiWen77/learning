# -*-coding:utf-8 -*-
'''
需要模块：sys
参数个数：len(sys.argv)
脚本名：    sys.argv[0]
参数1：     sys.argv[1]
参数2：     sys.argv[2]
'''
def fun(a,b):
    return a+b