<template>
  <div class="home">
    <el-container>
      <el-aside width="200px">
        <el-col class="header">
          {{ sysName }}  
        </el-col>
        <el-col>
          <el-menu 
            :default-active="$route.path" 
            class="el-menu-vertical-demo"
            background-color="#303133"
            text-color="#fff"
            active-text-color="#ffd04b">
            <!-- 建立目录 -->
            <template v-for="(item, index) in $router.options.routes" v-if="!item.hidden">
              <template v-for="child in item.children">
                <el-menu-item :index="child.path" @click="$router.push(child.path)">
                  <template slot="title">
                    <img class="icon" :src="child.iconCls" />
                    {{child.name}}
                  </template>
                </el-menu-item>
              </template>
            </template>
          </el-menu>
        </el-col>
      </el-aside>
      <!-- 详情 -->
      <el-container>
        <!-- 头部目录 -->
        <el-header>
          <div class="breadcrumb">
            <el-breadcrumb separator="\">
              <el-breadcrumb-item v-for="item in $route.matched" :key="item.path" >
                 {{ item.name }}
              </el-breadcrumb-item>
            </el-breadcrumb>
          </div>
        </el-header>
        <!-- 主要内容 -->
        <el-main class="content">
          <router-view></router-view>
        </el-main>

      </el-container>
    </el-container>
  </div>
</template>

<script>
  export default {
    data() {
      return {
        sysName: '固定资产收益计算平台',
        publications: null,
        showBondTable: false
      }
    },
    methods: {
    }
  }
</script>

<style>
/*  body {
    background-image: url(../assets/bg.jpg);
    background-size: 100%;
  }*/
  .el-container {
    height: 900px;
  }
  .el-aside {
    background-color: #303133;
  }
  .header {
    background-color: #303133;
    padding-left: 20px;
    color: #fff;
    line-height: 60px
  }
  .logo {
    background-color: #303133;
  }
  .icon {
    width: 16px;
    float: left;
    margin: 20px 20px 0px 0px;
  }
  .content {
    padding-top: 10px;
  }
  .el-header {
    background-color: #999999;
    color: #333;
    line-height: 60px;
  }
  .breadcrumb {
    margin-top: 25px;
  }
</style>