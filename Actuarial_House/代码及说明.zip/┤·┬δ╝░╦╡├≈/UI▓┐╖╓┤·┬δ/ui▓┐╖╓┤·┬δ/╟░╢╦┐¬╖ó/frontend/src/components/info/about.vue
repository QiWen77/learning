<template>
  <div id="app" style="width:1800px">
    <h1>欢迎访问固定资产收益计算平台</h1>
    <h1>Fixed Income Risk Calculation System</h1>
    <p>精算屋</p>
    <p>组长：王晓晨</p>
    <p>组员：梅传能，戚文，李泽萱，李然臻，刘皓冰，崔敬泽</p>
  </div>
</template>

<script>
  import axios from 'axios'
  export default {
    data() {
      return {
      }
    },
    created: function() {
    },
    methods: {
    }
  }
</script>