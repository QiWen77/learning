<!-- 层叠柱状图 -->
<style lang="stylus" scoped>
.multipleColumn
  height 1000px
  background url('../../assets/bg.jpg') no-repeat
  background-size 100% 100%
  .main
    width 100%
    height calc(100% - 100px)
    margin-top -15px
</style>

<template>
<div class="multipleColumn">
  <v-header :name="name" :legendArr="legendArr" :myChart="myChart"></v-header>
  <v-filter :myChart="myChart" v-if="myChart._dom"></v-filter>
  <div class="main"></div>
</div>

</template>

<script>
import Vue from 'vue'
import echarts from 'echarts'
import header from 'components/header/header'
import filter from 'components/filter/filter'
import axios from 'axios'

export default {
  // created() {
  //   this._getBondPrice()
  //   this.convertData(this.bondprices)
  // },
  data() {
    return {
      color: this.$store.state.color,
      myChart: {},
      name: 'Duration vs Ytm',
      bondprices: {},
      res2: []
    }
  },
  methods: {
    _init() {
      this.legendArr = this.myChart.getOption().series;
      this.legendArr.forEach((data) => {
        data.selected = true;
      })
      this.$root.charts.push(this.myChart)
      window.addEventListener('resize', function() {
        this.myChart.resize()
      }.bind(this))
    },
    _getBondPrice () {
      var chartData = [];
      axios.get('static/data/duration_ytm.json').then((res) => {
        chartData = res.data.data;
        // this.bondprices = res.data.data;
        // for (let i = 0; i < this.bondprices.length; i++) {
        //   // console.log(this.bondprices[i])
        //   this.res2.push(this.bondprices[i])
        // }
        // console.log("boundPrice", this.res2)
        // console.log(this.bondprices[2]);
        this.myChart = echarts.init(document.querySelector('.multipleColumn .main'));
        var chartOption = {
          title: {
            text: '',
            subtext: ''
          },
          tooltip: {
            trigger: 'axis',
            axisPointer: {
              show: true,
              type: 'cross',
              lineStyle: {
                type: 'dashed',
                width: 1
              }
            }
          },
          legend: {
            data: ['数据1']
          },
          toolbox: {
            show: true,
            feature: {
              mark: {show: true},
              dataZoom: {show: true},
              dataView: {show: true, readOnly: false},
              magicType: {show: true, type: ['line', 'bar']},
              restore: {show: true},
              saveAsImage: {show: true}
            }
          },
          calculable: true,
          xAxis: [
            {
              type: 'value'
            }
          ],
          yAxis: [
            {
              type: 'value',
              axisLine: {
                lineStyle: {
                  color: this.color
                }
              }
            }
          ],
          series: [
            {
              name: '数据2',
              type: 'line',
              data: chartData
            }
          ]
        };
        // chartOption.series[0].data = this.res2;
        this.myChart.setOption(chartOption);
        this._init()
        console.log('mounted', this.res2)
      })
      return chartData;
      // let res = [];
      // for (let i = 0; i < this.bondprices.length; i++) {
      //   console.log(bondprices[i])
      // }
    },
    convertData(data) {
      let res = [];
      // for (let i = 0; i < data.length; i++) {
      //   console.log(data[i])
      // }
      // console.log(this.bondprices)
      res.push([1, 2], [3, 4]);
      return res;
    }
  },
  components: {
    'v-header': header
    // 'v-filter': filter
  },
  mounted() {
    // 基于准备好的dom，初始化echarts实例
    var chartData = this._getBondPrice();
    console.log("test", chartData);
  }
}

</script>
