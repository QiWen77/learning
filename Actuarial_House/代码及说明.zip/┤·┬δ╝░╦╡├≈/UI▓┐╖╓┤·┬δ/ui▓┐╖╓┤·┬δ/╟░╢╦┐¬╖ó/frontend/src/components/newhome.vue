<template>
  <div class="home">
    <el-container>
      <el-aside width="200px">
        <el-col class="header">
          {{ sysName }}  
        </el-col>
        <el-col>
          <el-menu 
            :default-active="$route.path" 
            class="el-menu-vertical-demo"
            background-color="#222222"
            text-color="#fff"
            active-text-color="#ffd04b">
            <template v-for="(item, index) in $router.options.routes" v-if="!item.hidden">
              <el-menu-item :index="item.path" :key="item.path" @click="$router.push(item.path)" v-if="!item.leafs&&item.show">
                <template slot="title">
                  <img class="icon" :src="item.iconCls" />
                  {{item.name}}
                </template>
              </el-menu-item>

              <template v-for="child in item.children" v-if="item.leafs&&!item.show">
                <el-menu-item :index="child.path" :key="child.path" @click="$router.push(child.path)" v-if="!child.hidden">
                  <template slot="title">
                    <img class="icon" :src="child.iconCls" />
                    {{child.name}}
                  </template>
                </el-menu-item>
              </template>

              <el-submenu :index="index+''" v-if="item.leafs&&item.show">
                <template slot="title">
                  <img class="icon" :src="item.iconCls" />
                  {{item.name}}
                </template>
                <el-menu-item 
                  v-for="child in item.children" 
                  :index="child.path" 
                  :key="child.path" 
                  @click="$router.push(child.path)"
                  v-if="!child.hidden"
                  style="padding-left: 55px">
                  {{ child.name }}
                </el-menu-item>
              </el-submenu>
            </template>
          </el-menu>
        </el-col>
      </el-aside>
      <!-- 详情 -->
      <el-container>
        <el-header>
          <div class="breadcrumb">
          <el-breadcrumb separator="\">
            <el-breadcrumb-item v-for="item in $route.matched" :key="item.path" >
               {{ item.name }}
            </el-breadcrumb-item>
          </el-breadcrumb>
        </div>
        </el-header>
        <el-main class="content">
          <router-view></router-view>
        </el-main>
      </el-container>
    </el-container>
  </div>
</template>

<script>
  export default {
    data() {
      return {
        sysName: '固定资产收益计算平台',
        sysUserName: 'userID',
        sysUserAvatar: ''
      }
    },
    methods: {
    }
  }
</script>
<style type="text/css">
/*  body {
    background-image: url(../assets/bg.jpg);
    background-size: 100%;
  }*/
  .el-container {
    height: 900px;
  }
  .el-aside {
    background-color: #222222;
  }
  .header {
    background-color: #222222;
    padding-left: 20px;
    color: #fff;
    line-height: 60px
  }
  .logo {
    background-color: #222222;
  }
  .icon {
    width: 16px;
    float: left;
    margin: 20px 20px 0px 0px;
  }
  .content {
    padding-top: 10px;
  }
  .el-header {
    background-color: #999999;
    color: #333;
    line-height: 60px;
  }
  .breadcrumb {
    margin-top: 25px;
  }
</style>