<template>
  <div id="app" style="width:1000px">
    <!-- 输入信息 -->
    <el-row gutter="20">
      <!-- 左边栏 -->
      <el-col :span="9">
        <el-form ref="form" :model="form" label-width="160px">
          <el-form-item label="债券买入日期">
            <el-date-picker type="date" placeholder="2017-01-01" v-model="form.dateBuy" style="width: 100%;" value-format="yyyy-MM-dd"></el-date-picker>
          </el-form-item>
          <el-form-item label="债券到期时间">
            <el-date-picker type="date" placeholder="2017-01-01" v-model="form.dateEnd" style="width: 100%;" value-format="yyyy-MM-dd"></el-date-picker>
          </el-form-item>
          <el-form-item label="到期收益率">
            <el-input v-model.number="form.YTMinput" placeholder="0"></el-input>
          </el-form-item>
        </el-form>
      </el-col>
      <!-- 右边栏 -->
      <el-col :span="9">
        <el-form ref="form" :model="form" label-width="160px">
          <el-form-item label="票面利率（%）">
            <el-input v-model.number="form.bondRate" placeholder="0"></el-input>
          </el-form-item>
          <el-form-item label="付息次数（次/年）">
            <el-input v-model.number="form.rateFreq" placeholder="0"></el-input>
          </el-form-item>
          <el-form-item label="现值（全价）">
            <el-input v-model.number="form.pvI" placeholder="0"></el-input>
          </el-form-item>
        </el-form>
      </el-col>
    </el-row>
    <!-- 计算 -->
    <!-- 第一部分 -->
    <el-row gutter="20">
      <el-col :span="9">
        <el-form ref="form" :model="form" label-width="160px">
          <el-form-item label="计算方法">
            <el-select v-model="form.calculate_method" placeholder="请选择计算方法">
              <el-option label="根据利率模型" value="1"></el-option>
              <el-option label="已知到期收益率" value="2"></el-option>
              <el-option label="已知现值" value="3"></el-option>
            </el-select>
          </el-form-item>
        </el-form>
      </el-col>
      <el-col :span="9" style="margin-left:20px;margin-bottom:20px">
        <div id="b">
          <el-button type="primary" @click.native.prevent="reset()">重置</el-button>
          <el-button type="primary" @click.native.prevent="getValue()">计算</el-button>
        </div>
      </el-col>
    </el-row>
    <el-row gutter="20">
      <el-col :span="9">
        <el-form ref="form" :model="form" label-width="160px">
          <el-form-item label="现值（全价）">
            <el-input v-model.number="form.pv" placeholder="0"></el-input>
          </el-form-item>
          <el-form-item label="到期收益率">
            <el-input v-model.number="form.YTM" placeholder="0"></el-input>
          </el-form-item>
          <el-form-item label="凸性">
            <el-input v-model.number="form.convexity" placeholder="0"></el-input>
          </el-form-item>
        </el-form>
      </el-col>
      <el-col :span="9">
        <el-form ref="form" :model="form" label-width="160px">
          <el-form-item label="净价">
            <el-input v-model.number="form.cleanPrice" placeholder="0"></el-input>
          </el-form-item>
          <el-form-item label="修正久期">
            <el-input v-model.number="form.duration" placeholder="0"></el-input>
          </el-form-item>
        </el-form>
      </el-col>
    </el-row>
      <!-- <el-button type="primary" @click.native.prevent="tryPython()">py</el-button> -->
    <div>{{ notice }}</div>
    <!-- <div>{{ info }} {{ info2 }}</div> -->
  </div>
</template>
<script type="text/javascript">
  import axios from 'axios'
  export default {
    data() {
      return {
        form: {
          bondRate: 2.55,
          rateFreq: 1,
          dateBuy: '2017-12-27',
          dateEnd: '2019-1-28',
          calculate_method: null,
          YTMinput: null,
          pvI: null,
          pv: null,
          YTM: null,
          duration: null,
          convexity: null,
          cleanPrice: null
        },
        info: '',
        info2: '',
        notice: null
      }
    },
    methods: {
      getValue() {
        var flag = true
        // this.info2 = (this.form.calculate_method === '2')
        // this.notice = "dd"
        if (!this.form.dateBuy) {
          this.notice = "请选择买入日期"
          flag = false
        }
        if (!this.form.dateEnd) {
          this.notice = "请选择到期日"
          flag = false
        }
        if (!this.form.bondRate) {
          this.notice = "请输入票面利率"
          flag = false
        }
        if (!this.form.bondRate) {
          this.notice = "请输入付息次数"
          flag = false
        }
        if (!this.form.calculate_method) {
          this.notice = "请选择计算方法"
          flag = false
        }
        if (this.form.dateEnd < this.form.dateBuy) {
          this.notice = "到期日至少大于买入日期"
          flag = false
        }
        // this.notice = this.form.dateBuy.getMonth()
        // this.notice = (this.form.dateBuy > this.form.dateEnd)
        var setter = this.form.dateBuy
        var mature = this.form.dateEnd
        var coupon = this.form.bondRate / 100.0
        var freq = this.form.rateFreq
        var urlBase = "http://120.79.57.120:8083/api/search?" + 's=' + setter + '&m=' + mature + '&c=' + coupon + '&f=' + freq + '&me=' + this.form.calculate_method
        // this.info = urlBase
        // this.info2 = (this.form.calculate_method === '2')
        // this.notice = this.form.calculate_method
        if (this.form.calculate_method === '2') {
          if (!this.form.YTMinput) {
            this.notice = "请输入到期收益率"
            flag = false
          }
          urlBase = urlBase + '&ytm=' + this.form.YTMinput / 100.0
        } else if (this.form.calculate_method === '3') {
          if (!this.form.pvI) {
            this.notice = "请输入现值（全价）"
            flag = false
          }
          urlBase = urlBase + '&pv=' + this.form.pvI
        }
        // this.notice = flag
        if (flag) {
          axios.get(urlBase).then((res) => {
            var obj = res.data
            this.notice = obj
            this.form.pv = obj.pv
            this.form.cleanPrice = obj.clean_price
            this.form.YTM = obj.ytm * 100
            this.form.duration = obj.duration
            this.form.convexity = obj.convexity
            // this.notice = null
          })
          axios.get("http://120.79.57.120:8083/api/search?" + 's=' + setter + '&m=' + mature + '&c=' + coupon + '&f=' + freq + 'me=4').then((res) => {
            console.log("已经生成图表")
          })
        }
      },
      setCoupon(val) {
        this.form.isCouponBond = val
      },
      reset() {
        this.form.bondClass = null
        this.form.faceValue = null
        this.form.bondRate = null
        this.form.rateFreq = null
        this.form.datePub = null
        this.form.dateIn = null
        this.form.dateEnd = null
        this.form.valueIn = null
        this.form.valueOut = null
        this.form.isCouponBond = false
        this.form.bondNum = null
        this.form.YTM = null
      }
    }
  }
</script>
