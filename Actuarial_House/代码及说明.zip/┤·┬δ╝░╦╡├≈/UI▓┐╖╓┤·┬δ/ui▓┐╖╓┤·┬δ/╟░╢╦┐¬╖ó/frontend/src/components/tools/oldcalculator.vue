<template>
  <div id="app" style="width:1000px">
    <el-row gutter="20">
      <el-col :span="9">
        <el-form ref="form" :model="form" label-width="160px">
          <el-form-item label="债券类型">
            <el-select v-model="form.bondClass" placeholder="请选择债券类型">
              <el-option label="附息债券" value="couponBond" @click.native.prevent="setCoupon(true)"></el-option>
              <el-option label="零息债权" value="zeroCouponBond" @click.native.prevent="setCoupon(false)"></el-option>
            </el-select>
          </el-form-item>
          <el-form-item label="附息债券利率（%）">
            <el-input v-model.number="form.bondRate" placeholder="0" :disabled="!form.isCouponBond"></el-input>
          </el-form-item>
<!--           <el-form-item label="债券发行日期">
            <el-date-picker type="date" placeholder="2017-01-01" v-model="form.datePub" style="width: 100%;"></el-date-picker>
          </el-form-item> -->
          <el-form-item label="债券买入日期">
            <el-date-picker type="date" placeholder="2017-01-01" v-model="form.dateBuy" style="width: 100%;"></el-date-picker>
          </el-form-item>
          <el-form-item label="债券到期时间">
            <el-date-picker type="date" placeholder="2017-01-01" v-model="form.dateEnd" style="width: 100%;"></el-date-picker>
          </el-form-item>
        </el-form>
      </el-col>

      <el-col :span="9">
        <el-form ref="form" :model="form" label-width="160px">
          <el-form-item label="债券面额">
            <el-input v-model.number="form.faceValue" placeholder="0"></el-input>
          </el-form-item>
          <el-form-item label="利息支付频率（次/年）">
            <el-input v-model.number="form.rateFreq" placeholder="0" :disabled="!form.isCouponBond"></el-input>
          </el-form-item>
          <el-form-item label="买入债券数量">
            <el-input v-model.number="form.bondNum" placeholder="0"></el-input>
          </el-form-item>
          <el-form-item label="债券买入价格（总价）">
            <el-input v-model.number="form.valueIn" placeholder="0"></el-input>
          </el-form-item>
          <el-form-item label="到期本息和（总价）">
            <el-input v-model.number="form.valueOut" placeholder="0"></el-input>
          </el-form-item>
        </el-form>
      </el-col>
    </el-row>
    <div id="b" style="margin-left:200px;margin-bottom:20px">
      <el-button type="primary" @click.native.prevent="reset()">重置</el-button>
      <el-button type="primary" @click.native.prevent="getValue()">计算到期本息和</el-button>
      <el-button type="primary" @click.native.prevent="getYield()">计算到期收益率（YTM）</el-button>
    </div>
    <el-row gutter="20">
      <el-col :span="9">
        <el-form ref="form" :model="form" label-width="160px">
          <el-form-item label="现值（全价）">
            <el-input v-model.number="form.pv" placeholder="0"></el-input>
          </el-form-item>
          <el-form-item label="到期收益率">
            <el-input v-model.number="form.YTM" placeholder="0"></el-input>
          </el-form-item>
          <el-form-item label="凸性">
            <el-input v-model.number="form.convexity" placeholder="0"></el-input>
          </el-form-item>
        </el-form>
      </el-col>
      <el-col :span="9">
        <el-form ref="form" :model="form" label-width="160px">
          <el-form-item label="净价">
            <el-input v-model.number="form.cleanPrice" placeholder="0"></el-input>
          </el-form-item>
          <el-form-item label="修正久期">
            <el-input v-model.number="form.duration" placeholder="0"></el-input>
          </el-form-item>
        </el-form>
      </el-col>
    </el-row>
      <el-button type="primary" @click.native.prevent="tryPython()">py</el-button>
    <div>{{ info }} {{ info2 }}</div>
  </div>
</template>
<script type="text/javascript">
  import axios from 'axios'
  export default {
    data() {
      return {
        form: {
          bondClass: null,
          faceValue: null,
          bondRate: null,
          rateFreq: null,
          datePub: null,
          dateIn: null,
          dateEnd: null,
          valueIn: null,
          valueOut: null,
          isCouponBond: false,
          bondNum: null,
          pv: null,
          YTM: null,
          duration: null,
          convexity: null,
          cleanPrice: null
        },
        info: '',
        info2: ''
      }
    },
    methods: {
      getValue() {
        if (this.form.isCouponBond === true) {
          var times
          var interest
          times = Math.ceil((this.form.dateEnd - this.form.datePub) / 86400000.0 / 365.0 * this.form.rateFreq)
          interest = this.form.bondRate / 100.0 / this.form.rateFreq * this.form.faceValue * times
          this.form.valueOut = (interest + this.form.faceValue) * this.form.bondNum
        } else {
          this.form.valueOut = this.form.faceValue * this.form.bondNum
        }
      },
      getYield() {
        var years
        var value2
        years = (this.form.dateEnd - this.form.dateIn) / 86400000.0 / 365.0
        if (this.form.isCouponBond === true) {
          var times
          var interest
          times = Math.ceil((this.form.dateEnd - this.form.datePub) / 86400000.0 / 365.0 * this.form.rateFreq)
          interest = this.form.bondRate / 100.0 / this.form.rateFreq * this.form.faceValue * times
          value2 = (interest + this.form.faceValue) * this.form.bondNum
        } else {
          value2 = this.form.faceValue * this.form.bondNum
        }
        this.form.YTM = (value2 - this.form.valueIn) / (this.form.valueIn * years)
        console.log('calculate!');
      },
      setCoupon(val) {
        this.form.isCouponBond = val
      },
      // 访问接口
      tryPython() {
        var setter = this.form.dateIn.getFullYear() + '-' + this.form.dateIn.getMonth() + '-' + this.form.dateIn.getDay()
        this.info = "tyr"
        // console.log('??')
        axios.get('http://127.0.0.1:8085/api/search?s=2017-1-1&m=2018-1-1&c=0.05&f=1').then((res) => {
          var obj = res.data
          this.info = obj.pv_key
        })
      },
      reset() {
        this.form.bondClass = null
        this.form.faceValue = null
        this.form.bondRate = null
        this.form.rateFreq = null
        this.form.datePub = null
        this.form.dateIn = null
        this.form.dateEnd = null
        this.form.valueIn = null
        this.form.valueOut = null
        this.form.isCouponBond = false
        this.form.bondNum = null
        this.form.YTM = null
      }
    }
  }
</script>
