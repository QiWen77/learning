<template>
  <div id="app" style="width:1000px">
    <el-button type="primary" @click.native.prevent="_getPubList()">重置</el-button>
    <el-form ref="form" :model="form" label-width="160px">
      <el-form-item label="债券类型">
        <el-select v-model="form.bondClass" placeholder="请选择债券类型">
          <el-option label="附息债券" value="couponBond" @click.native.prevent="setCoupon(true)"></el-option>
          <el-option label="零息债权" value="zeroCouponBond" @click.native.prevent="setCoupon(false)"></el-option>
        </el-select>
      </el-form-item>
      <el-form-item label="发行方">
        <el-select v-model="form.bondPub" placeholder="请选择债券发行单位">
          <el-option 
            v-for="item in publications" 
            :key="item.value"
            :label="item.label"
            :value="item.value" 
            @click.native.prevent="setPub(item.value)">
          </el-option>
        </el-select>
      </el-form-item>
    </el-form>
  </div>
</template>

<script>
  import axios from 'axios'
  export default {
    data() {
      return {
        form: {
          bondPub: null,
          bondClass: null
        },
        publications: null
      }
    },
    created: function() {
      this._getPubList()
    },
    methods: {
      _getPubList () {
        axios.get('static/bond/publications.json').then((res) => {
          this.publications = res.data.publications
        })
        console.log("载入债券发行单位数据")
      }
    }
  }
</script>