import Vue from 'vue'
import App from './App'
import Vuex from 'vuex'
import VueRouer from 'vue-router'

// import Login from 'components/login'
import NotFound from 'components/404'

import Home from 'components/home'
import Member from 'components/info/member'
import About from 'components/info/about'
import BondTable from 'components/bondTable/bondTable'
import Calculator from 'components/tools/calculator'
import Selector from 'components/tools/selector'
import Charts from 'components/dashboard/dashboard'
import Market from 'components/bondTable/Market'

import iconTrade from 'assets/trade.svg'
import iconCalculator from 'assets/Calculator.svg'
import iconPic from 'assets/pic-filling.svg'
import iconExl from 'assets/exl.svg'

// import axios from 'axios'

import {
  Aside, 
  Breadcrumb,
  BreadcrumbItem,
  Button,
  Checkbox,
  Col,
  Container, 
  DatePicker,
  Dropdown, 
  DropdownMenu,
  DropdownItem,
  Form,
  FormItem,
  Header, 
  Main,
  Menu,
  MenuItem, 
  Input, 
  Option,
  Pagination,
  Row,
  Select,
  Submenu, 
  Table, 
  TableColumn 
} from 'element-ui'

// import 'element-ui/lib/theme-chalk/index.css'

Vue.use(Aside)
Vue.use(Breadcrumb)
Vue.use(BreadcrumbItem)
Vue.use(Button)
Vue.use(Checkbox)
Vue.use(Col)
Vue.use(Container)
Vue.use(DatePicker)
Vue.use(Dropdown)
Vue.use(DropdownMenu)
Vue.use(DropdownItem)
Vue.use(Form)
Vue.use(FormItem)
Vue.use(Header)
Vue.use(Main)
Vue.use(Menu)
Vue.use(MenuItem)
Vue.use(Input)
Vue.use(Option)
Vue.use(Pagination)
Vue.use(Row)
Vue.use(Select)
Vue.use(Submenu)
Vue.use(Table)
Vue.use(TableColumn)

Vue.use(VueRouer)
Vue.use(Vuex)

// axios.default.withCredentials = true
//debug
// Vue.config.debug = true
// axios.default.withCredentials = true
// Vue.prototype.$axios = axios

const store = new Vuex.Store({
  state: {
    count: 0,
    color: ['#325B69', '#698570', '#AE5548', '#6D9EA8', '#9CC2B0', '#C98769']
  }
});

const router = new VueRouer({
  routes: [
    // {
    //   path: '/login',
    //   component: Login,
    //   name: 'login',
    //   hidden: true
    // },
    {
      path: '/', name: '首页', component: Home, hidden: false,
      children:[
        { path: '/about', name: '关于项目', component: About, show: true},
        { path: '/bondTable', name: '债券信息', component: BondTable, iconCls: iconExl},
        { path: '/Market', name: '市场信息', component: Market, iconCls: iconTrade},
        { path: '/calculator', name: '债券计算器', component: Calculator, iconCls: iconCalculator},
        { path: '/charts', name: '图表分析', component: Charts, iconCls: iconPic}
      ]
    }
  ],
  linkActiveClass: 'active'
})

new Vue({
  router,
  store,
  template: '<App>',
  components: {
    App
  },
  data: {
    eventHub: new Vue(),
    charts: []
  },
}).$mount('#app')

router.push('')
