#coding:utf-8
import codecs # To support chinese
import requests
from bs4 import BeautifulSoup
import json 
import re
from pymongo import MongoClient
import datetime

headers = {'User-Agent':'Mozilla/5.0(Windows NT 6.1;WOW64)AppleWebKit/537.36(KHTML,like Gecko) Chrome/53.0.2785.104 Safari/537.3 Core/1.53.1708.400 QQBrowser/9.5.9635.400'}
## url = "http://vip.stock.finance.sina.com.cn/quotes_service/api/json_v2.php/Market_Center.getHQNodeDataSimple?page=1&num=40&sort=symbol&asc=1&node=hs_z&_s_r_a=auto"
link1 = "http://vip.stock.finance.sina.com.cn/quotes_service/api/json_v2.php/Market_Center.getHQNodeDataSimple?page="
link2 = "&num=40&sort=symbol&asc=1&node=hs_z&_s_r_a=auto"
for page in range(1,129):
    print("Page %d "%page)
    url = link1+str(page)+link2
    data = requests.get(url,headers=headers)
    soup = BeautifulSoup(data.content,'html.parser',from_encoding='utf-8')

## To transfer data.text into {key:value} pair
    a = data.text
    string1 = re.compile('symbol')
    string2 = string1.sub('\"symbol\"',a) 
    string3 = re.compile('name')
    string4 = string3.sub('\"name\"',string2) 
    string5 = re.compile('trade')
    string6 = string5.sub('\"trade\"',string4)
    string7 = re.compile('pricechange')
    string8 = string7.sub('\"pricechange\"',string6)
    string9 = re.compile('changepercent')
    string10 = string9.sub('\"changepercent\"',string8)
    string11 = re.compile('buy')
    string12 = string11.sub('\"buy\"',string10)
    string13 = re.compile('sell')
    string14 = string13.sub('\"sell\"',string12)
    string15 = re.compile('settlement')
    string16 = string15.sub('\"settlement\"',string14)
    string17 = re.compile('open')
    string18 = string17.sub('\"open\"',string16)
    string19 = re.compile('high')
    string20 = string19.sub('\"high\"',string18)
    string21 = re.compile('low')
    string22 = string21.sub('\"low\"',string20)
    string23 = re.compile('volume')
    string24 = string23.sub('\"volume\"',string22)
    string25 = re.compile('amount')
    string26 = string25.sub('\"amount\"',string24)
    string27 = re.compile('code')
    string28 = string27.sub('\"code\"',string26)
    string29 = re.compile('ticktime')
    string30 = string29.sub('\"ticktime\"',string28)
    data = string30
    ## Transfer string into list by json
    json_data = json.loads(data)
    ## mongodb set
    client = MongoClient('localhost',27018)
    db = client.bond_data
    collection = db.sina_data
    ## Getting the datailed information and Inserting into mongodb
    link3 = "http://money.finance.sina.com.cn/bond/quotes/"
    link4 = ".html"
    for i in range(len(json_data)):
        print("Number %d document" %i)
        symbol = json_data[i]['symbol']
        info_url = link3+symbol+link4
        # print(info_url)
        response = requests.get(info_url,headers=headers)
        info_soup = BeautifulSoup(response.content,'html.parser')
        ## Getting related bond list
        '''
        it will return a dict where the key is the current bond code,the value is a list that contains all the related bond codes
        '''
        # print(soup)
        related_bond = info_soup.find_all('script',attrs={"type":"text/javascript"})[-5].text
        # print(type(related_bond))
        related_bond_code = related_bond.strip().replace('var relatedList=[[','').replace(']];','').split(',')
        current_bond = info_url.split('/')[-1].split('.')[-2]
        # current_bond = current_bond+"_"+"related_bond"
        related_dict = {'相关证券':{current_bond:related_bond_code}}
        # print("{current:related_list}:\n",related_dict)

        ## Getting bond transaction

        transaction_title = info_soup.find('div',attrs={'class':'title tit03'}).text
        transaction = info_soup.find_all('table',attrs={'class':'tbl'})[0].find_all('td',attrs={})
        transaction_list=[]
        for j in transaction:
            # print(i.text)
            transaction_list.append(j.text)
        # print(transaction_title)
        # print(transaction_list)
        transaction_dict = {transaction_title:{transaction_list[0]:{transaction_list[1]:{transaction_list[6]:transaction_list[7],transaction_list[12]:transaction_list[13]},transaction_list[2]:{transaction_list[6]:transaction_list[8],transaction_list[12]:transaction_list[14]},transaction_list[3]:{transaction_list[6]:transaction_list[9],transaction_list[12]:transaction_list[15]},transaction_list[4]:{transaction_list[6]:transaction_list[10],transaction_list[12]:transaction_list[16]},transaction_list[5]:{transaction_list[6]:transaction_list[11],transaction_list[12]:transaction_list[17]}}}}
        # print(transaction_dict)

        ## Getting the abstract of the bond

        abstract_title = info_soup.find('div',attrs={'class':'title tit04'}).text
        abstract = info_soup.find_all('table',attrs={'class':'tbl'})[1].find_all('td',attrs={})
        abstract_list = []
        for k in abstract:
            # print(j.text)
            abstract_list.append(k.text)
        # print(abstract_list)
        abstract_dict = {abstract_title:{abstract_list[0]:abstract_list[1],abstract_list[2]:abstract_list[3],abstract_list[4]:abstract_list[5],abstract_list[6]:abstract_list[7],abstract_list[8]:abstract_list[9],abstract_list[10]:abstract_list[11],abstract_list[12]:abstract_list[13],abstract_list[14]:abstract_list[15],abstract_list[16]:abstract_list[17],abstract_list[18]:abstract_list[19],abstract_list[20]:abstract_list[21],abstract_list[22]:abstract_list[23],abstract_list[24]:abstract_list[25],abstract_list[26]:abstract_list[27],abstract_list[28]:abstract_list[29]}}
        # data tag
        date = datetime.datetime.now()
        date_dict={'date':date.strftime('%Y-%m-%d')}#%H:%M:%S'
        # print(date_dict)
        info_1 = json_data[i].update(date_dict)
        info_2 = json_data[i].update(related_dict)
        info_3 = json_data[i].update(transaction_dict)
        info_4 = json_data[i].update(abstract_dict)
        # print(json_data[i])
        collection.insert_one(json_data[i])



